<!--Name: Jato Ulrich Guiffo Kengne 
    Date: April 08, 2023 
    Section: CST 8285 section 303
    Assignment: 02 
    File: footer.php
    Assignment objective: Use HTML, CSS, JavaScript, PHP and 
    MySQL to buils a web aplication to perform CRUD operation
-->
<footer>
    <p class="footer-text">&copy;
        <?php echo date("Y"); ?> Jato Ulrich Guiffo Kengne. Inspired from sample provided in CST8285 Course
        <!-- <a href = "https://www.tutorialrepublic.com/php-tutorial/php-mysql-crud-application.php">
            Updated educational version inspired from tutorialrepublic CRUD sample
            </a> -->
    </p>

</footer>